package p1;

/*import user_management.Register;

public class demo
{
	   private static Register sharedObject;

	    static 
	    {
	        // Initialize the shared object here
	        sharedObject = new Register();
	    }
	   
	   private demo()
	   {
		   sharedObject = new Register();
	   }

	    public static Register getSharedObject() 
	    {
	        return sharedObject;
	    }
}*/
